MYSQL2_VERSION = '~> 0.2.18'
RAILS_VERSION = '~> 3.0.17'

eval File.read(File.expand_path('../../Gemfile', __FILE__))
