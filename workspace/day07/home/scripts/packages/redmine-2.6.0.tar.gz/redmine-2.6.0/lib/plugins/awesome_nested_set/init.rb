require File.dirname(__FILE__) + '/lib/awesome_nested_set'
